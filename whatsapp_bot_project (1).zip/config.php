<?php
$admin_email = "admin@emailkamu.com"; // Ganti dengan email kamu
?>
